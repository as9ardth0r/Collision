from cx_Freeze import setup, Executable
  
executables = [
        Executable(script = "Collision.py",icon = "Collision.ico" )
]
# ne pas mettre "base = ..." si le programme n'est pas en mode graphique, comme c'est le cas pour chiffrement.py.
  
buildOptions = dict( 
        includes = ["bitcoin","hashlib","base58","random","time","os","binascii","rich.console"],
        include_files = ["Collision.ico"]
)
  
setup(
    name = "Collision GPU python & C++",
    version = "1.0",
    description = "Collision GPU python & C++",
    author = "As9ard",
    options = dict(build_exe = buildOptions),
    executables = executables
)